# Changelog

## 3.4.0 - 2026-11-19

### Added
- Added MCP `raster_calculator` for raster expressions.
- Added MCP `raster_info` to inspect raster properties.

### Improved
- Improved handling of raster outputs in `run_processing`.
- Improved algorithm information returned by `processing_help`.

### Notes
- Additional testing across QGIS Processing algorithms is ongoing.

## 3.3.0

### Changed
- The `Tema_mapa_base` theme is used as a background instead of getting its own map.
- Each thematic map now uses the extent of its own theme; the base-map layers are excluded from extent calculations and the locator map.

## 3.0.2

### Added
- Added a paper-size selector to the automatic print-layout dialog, with DIN A3 and DIN A4 landscape options.
- Added an explanation in the layout-creation dialog describing how map themes, the `Tema_Localizacion` locator map, and legends are handled.

### Changed
- Layout content dimensions and generated layout names now reflect the selected paper size.
- The `Tema_mapa_base` theme is added beneath thematic layers (not the locator), and each map uses its own theme extent without counting the base-map layers.
- Renamed the toolbar action to **Create A3/A4 Layout**.
- Updated the README and plugin metadata to describe A3/A4 layout support.
